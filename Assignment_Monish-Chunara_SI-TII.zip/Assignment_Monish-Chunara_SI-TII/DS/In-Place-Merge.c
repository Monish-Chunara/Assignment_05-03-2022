//Program for in-place merging two sorted arrays
//Monish Chunara - Shift I Track II

#include<stdio.h>

void swap(int *, int *);

void main()
{
int m,n;
int i,j,temp;

printf("\nEnter the size of Array X: ");
scanf("%d",&m);

printf("\nEnter the size of Array Y: ");
scanf("%d",&n);

int X[m];
int Y[n];

printf("\nEnter the elements of array X: ");
for(i=0;i<m;i++)
	scanf("%d",&X[i]);

printf("\nEnter the elements of array Y: ");
for(i=0;i<n;i++)
	scanf("%d",&Y[i]);

printf("\n\nBefore In-Place Merging the sorted arrays: ");

printf("\nArray X: \n");
for(i=0;i<m;i++)
	printf("%d ",X[i]);

printf("\n\nArray Y: \n");
for(i=0;i<n;i++)
	printf("%d ",Y[i]);

//In-place merging
for(i=0;i<m;i++)
{
	if(X[i] > Y[0])
	{
		swap(&X[i], &Y[0]);

		temp=Y[0];
		
		for(j=1;j<n;j++)
		{
			if(temp > Y[j])
				Y[j-1]=Y[j];
			else
				break;
		}
		Y[j-1]=temp;
	}
}

printf("\n\nAfter In-Place Merging the sorted arrays: ");

printf("\nArray X: \n");
for(i=0;i<m;i++)
	printf("%d ",X[i]);

printf("\n\nArray Y: \n");
for(i=0;i<n;i++)
	printf("%d ",Y[i]);

printf("\n\n");
}

void swap(int *n1, int *n2)
{
int temp;
temp = *n1;
*n1 = *n2;
*n2 = temp;
}
