//Program to generate binary numbers between 1 to n using a Queue
//Monish Chunara - Shift I Track II

#include<stdio.h>

void enque(unsigned int [],int *,int *,int,unsigned int);
unsigned int deque(unsigned int [],int *,int *,int);

void main()
{
int n;
unsigned int x;

printf("\nEnter the value of n: ");
scanf("%d",&n);

int N=n+1;
unsigned int Queue[N];		//unsigned int to increase the range of numbers
int front=-1, rear=-1;

enque(Queue, &front, &rear, N, 1);		//Initializing Queue with '1'

printf("\nBinary Numbers between 1 and %d are: \n\n",n);
for(int i=0; i<n; i++)
{
	x=deque(Queue, &front, &rear, N);
	printf("%u ",x);
	enque(Queue, &front, &rear, N, (x*10)+0);
	enque(Queue, &front, &rear, N, (x*10)+1);
}

printf("\n\n");
}

//Using Circular Queue for efficient storage usage
//Enque function definition
void enque(unsigned int q[],int *f,int *r,int n,unsigned int x)
{
	int temp=*r;
	
	if(*r==n-1)
		*r=0;
	else
		*r=*r+1;

	if(*r==*f)
	{
		printf("\nQueue Overflow\n");
		*r=temp;
	}
	else
	{
		q[*r]=x;

		if(*f==-1)
			*f=0;
	}
}

//Deque function definition
unsigned int deque(unsigned int q[],int *f,int *r,int n)
{
	int temp;
	
	if(*f==-1)
		printf("\nQueue Underflow\n");
	else
	{
		temp=q[*f];

		if(*f==*r)
		{
			*f=-1;
			*r=-1;
		}
		else if(*f==n-1)
		{
			*f=0;
		}
		else
		{
			*f=*f+1;
		}

		return temp;
	}
}
