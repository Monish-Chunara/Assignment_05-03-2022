//Program to search a number and print the array in sequence
//Monish Chunara - Shift I Track II

#include<stdio.h>

void main()
{
	int A[10] = {1,5,4,8,9,2,0,6,11,7};
	int i,n;

	printf("\nThe array elements are: \n");
	for(i=0;i<10;i++)
		printf("%d ",A[i]);

	//Searching
	printf("\n\nEnter the element to search: ");
	scanf("%d",&n);

	for(i=0;i<10;i++)
	{
		if(A[i]==n)
		{
			printf("\nYES");
			break;
		}
	}

	if(i==10)
		printf("\nNO");

	
	//Printing number following the sequence of elements in array
	printf("\n\nThe number following the sequence if array elements is : ");
	for(i=0;i<10;i++)
		printf("%d",A[i]);
	
	printf("\n\n");
}
