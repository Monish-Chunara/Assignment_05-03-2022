//Program to depict working of a library
//Monish Chunara - Shift I Track II

#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<string.h>

struct library
{
	int acc_no;
	char title[50];
	char author[20];
	int price;
	int flag;		//0=not issued, 1=issued
}*books;

void PrintInfo(struct library);

void main()
{
	int choice;
	int i=0, count=0,n,j;
	int num_books=0;	//number of books in the library (unissued)
	int max=50;
	char query[20];

	//allocating space for 50 books, if number of books becomes > 50, memory will be reallocated
	books = (struct library *)malloc(sizeof(struct library)*max);
	struct library temp;
	
	printf("\n***************Welcome to the Library***************");
	
	do
	{
	printf("\n\nMenu\n------------------------------");
	printf("\n1. Add book information\n2. Display book information\n3. List all books of given author\n4. List the title of specified book\n5. List the count of books in the library\n6. List the books in the order of accession number\n7. Issue a book\n8. Return a book\n9. Exit");
	printf("\n------------------------------\nChoice: ");
	scanf("%d",&choice);

	switch(choice)
	{
	case 1: if(count==max)
		{
			max+=10;
			books = (struct library *)realloc(books, sizeof(struct library)*max);
		}

		printf("\nEnter the accession number: ");
		scanf("%d",&books[i].acc_no);

		printf("\nEnter the title of the book: ");
		getchar();
		scanf("%[^\n]%*c",books[i].title);		//To allow space in the title

		printf("\nEnter the author name: ");
		scanf("%[^\n]%*c",books[i].author);		//To allow space in author name

		printf("\nEnter the price of the book: ");
		scanf("%d",&books[i].price);

		books[i].flag = 0;			//newly added book is not issued

		printf("\nBook added to the Library.\n");
		i++;
		count++;
		num_books++;
		break;

	case 2: if(count==0)
		{
			printf("\nNo books in the library.");
			break;
		}
		else
		{
			printf("\nList of all the books in the Library: \n");
			for(int i=0;i<count;i++)
			{
				PrintInfo(books[i]);
			}
		}
		break;
	
	case 3: printf("\nEnter the author name: ");
		getchar();
		scanf("%[^\n]%*c",query);

		printf("\nList of all the books by author %s:\n",query);
		for(int i=0;i<count;i++)
		{
			if(strcmp(query,books[i].author)==0)
				PrintInfo(books[i]);
		}
		break;

	case 4: printf("\nEnter Accession number of the required book: ");
		scanf("%d",&n);
		
		for(j=0;j<count;j++)
		{
			if(books[j].acc_no == n)
			{
				printf("\nThe title of the book is: %s.\n", books[j].title);
				break;
			}
		}
		
		if(j==count)
			printf("\nNo book with accession number %d.\n",n);
		break;
	
	case 5: printf("\nTotal number of books in the library = %d", count);
		printf("\nTotal number of unissued books in the library = %d", num_books);
		break;

	case 6: //sorting
		for(int i=0;i<count-1;i++)
		{
			for(int j=i+1;j<count;j++)
			{
				if(books[j].acc_no < books[i].acc_no)
				{
					temp = books[i];
					books[i] = books[j];
					books[j] = temp;
				}
			}
		}

		printf("\nBooks in the order of accession number: ");
		for(int i=0;i<count;i++)
		{
			PrintInfo(books[i]);
		}
		break;

	case 7: //Issue a book
		printf("\nEnter the title of the book to issue: ");
		getchar();
		scanf("%[^\n]%*c",query);

		for(j=0;j<count;j++)
		{
			if(strcmp(query,books[j].title)==0)
			{
				if(books[j].flag==0)
				{
					books[j].flag=1;
					num_books--;
					printf("\nBook Issued.\n");
				}
				else
					printf("\nBook is already issued.\n");
				break;
			}
		}
		if(j==count)
			printf("\nBook not found!\n");
		break;

	case 8: //Update the issue status of a returned book
		printf("\nEnter the title of the returned book: ");
		getchar();
		scanf("%[^\n]%*c",query);

		for(j=0;j<count;j++)
		{
			if(strcmp(query,books[j].title)==0)
			{
				if(books[j].flag==1)
				{
					books[j].flag=0;
					num_books++;
					printf("\nBook returned.\n");
				}
				else
					printf("\nBook was not issued.\n");
				break;
			}
		}
		if(j==count)
			printf("\nBook not found!\n");

		break;

	case 9: printf("\nThank you!\n");
		break;

	default: printf("\nInvalid Choice\n");
		break;
	}

	}while(choice!=9);
	
}

void PrintInfo(struct library book)
{
	printf("\n\nBook Accession Number: %d",book.acc_no);
	printf("\nTitle: %s",book.title);
	printf("\nAuthor: %s",book.author);
	printf("\nPrice: %d",book.price);
	printf("\nIssue status: %d",book.flag);

}
