//Program to calculate total marks and percentage
//Monish Chunara - Shift I Track II

#include<stdio.h>

/*
Here structure is used to return both values from the function
Other options are to use pointers, use array, declare global variable

As per the problem statement, structure is best option as returning pointer to local array variable will result into segmentation fault
Global variable was not used as problem statement required the function to return the values
*/

struct result
{
	int total;
	float percentage;
};

struct result CalculateResult(int []);

void main()
{
	struct result student1;		
	int marks[3];
	int i;

	for(i=0;i<3;i++)
	{
		printf("\nEnter marks in subject %d: ", i+1);
		scanf("%d",&marks[i]);
	}

	student1 = CalculateResult(marks);

	printf("\nTotal Marks = %d",student1.total);
	printf("\nPercentage = %.2f %%\n\n",student1.percentage);
}

struct result CalculateResult(int marks[])
{
	struct result s1;
	float sum=0;

	for(int i=0; i<3; i++)
		sum += marks[i];

	s1.total = sum;
	s1.percentage = (sum/300)*100;

	return s1;
}
