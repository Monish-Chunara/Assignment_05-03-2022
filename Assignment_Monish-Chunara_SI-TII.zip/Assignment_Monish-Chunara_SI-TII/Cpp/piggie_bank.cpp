//Program to realize a Piggie Bank
//Monish Chunara - Shift I Track II

#include<iostream>
using namespace std;

class AddAmount{
	public:
		int amount=50;		//initial value

		AddAmount()
		{
			cout << "\nDefault Constructor" <<endl;
		}

		AddAmount(int amt)
		{
			cout << "\nParameterized Constructor" <<endl;
			amount += amt;
		}
};

int main()
{
	AddAmount p1;
	cout << "Final amount in Piggy Bank 1 = Rs. " << p1.amount << endl;

	AddAmount p2(200);
	cout << "Final amount in Piggy Bank 2 = Rs. " << p2.amount << endl;
}
