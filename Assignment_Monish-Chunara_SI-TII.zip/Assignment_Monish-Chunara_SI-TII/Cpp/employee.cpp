//Program for Employee Salary Calculation
//Monish Chunara - Shift I Track II

#include<iostream>
using namespace std;

class Employee{
	int final_salary;
	int work_hours;
	public:
		void getInfo(int salary, int hours)
		{
				final_salary = salary;
				work_hours = hours;
		}

		void AddSal()
		{
			if(final_salary < 500)
				final_salary += 10;
		}

		void AddWork()
		{
			if(work_hours > 6)
				final_salary += 5;
		}

		void printFinal()
		{
			AddSal();
			AddWork();
			
			cout << "The final salary of this employee is " << final_salary << " $"<< endl;
		}
};

int main()
{
	Employee e1,e2,e3,e4;
	e1.getInfo(200,8);
	cout<< "\nEmployee 1" <<endl;
	//AddSal() and AddWork() are called in printFinal() member function itself
	e1.printFinal();

	e2.getInfo(600,7);
	cout<< "\nEmployee 2" <<endl;
	e2.printFinal();

	e3.getInfo(400,5);
	cout<< "\nEmployee 3" <<endl;
	e3.printFinal();

	e4.getInfo(700,4);
	cout<< "\nEmployee 4" <<endl;
	e4.printFinal();
}
