//Program to perform matrix operations
//Monish Chunara - Shift I Track II

#include<iostream>
using namespace std;

class Matrix{

	public:
		int rows, columns;
		int **M;

		Matrix()
		{
			cout << "Default Constructor" << endl;
		}
		
		Matrix(int r, int c)
		{
			rows = r;
			columns = c;
		
			//Dynamic Allocation of 2-D Array using new operator
			M = new int*[rows];
			for(int i=0; i<r; i++)
			{
				M[i] = new int[c];
			}
		}

		void setElement(int i, int j, int value)
		{
			M[i][j] = value;	//assuming i<rows and j<columns
		}

		Matrix Add(Matrix M1, Matrix M2)
		{
			Matrix M3(M1.rows, M1.columns);
			int i,j;
			for(i=0;i<M3.rows;i++)
			{
				for(j=0;j<M3.columns;j++)
				{
					M3.M[i][j] = M1.M[i][j] + M2.M[i][j];
				}
			}
			return M3;
		}

		Matrix Multiply(Matrix M1, Matrix M2)
		{
			Matrix M3(M1.rows, M2.columns);
			int i,j,k;
			for(i=0;i<M1.rows;i++)
			{
				for(j=0;j<M2.columns;j++)
				{
					M3.M[i][j]=0;
					for(k=0;k<M1.columns;k++)
						M3.M[i][j] += M1.M[i][k] * M2.M[k][j];
				}
			}
			return M3;
		}

		void Free()
		{
			//Deallocation of memory
			for(int i=0;i<rows;i++)
				delete [] M[i];
			delete [] M;
		}

		void Print()
		{
			int i,j;
			for(i=0;i<rows;i++)
			{
				for(j=0;j<columns;j++)
				{
					cout << M[i][j] << " ";
				}
				cout << endl;
			}
		}
};

int main()
{
	Matrix M1(2,2);
	Matrix M2(2,2);
	Matrix M3;

	M1.setElement(0,0,3);
	M1.setElement(0,1,4);
	M1.setElement(1,0,2);
	M1.setElement(1,1,1);
	
	M2.setElement(0,0,1);
	M2.setElement(0,1,5);
	M2.setElement(1,0,3);
	M2.setElement(1,1,7);

	cout << "Matrix-1" <<endl;
	M1.Print();

	cout << "\nMatrix-2" <<endl;
	M2.Print();

	cout << "\nAddition" <<endl;
	M3 = M3.Add(M1,M2);
	M3.Print();

	cout << "\nMultiplication" <<endl;
	M3 = M3.Multiply(M1,M2);
	M3.Print();

	M1.Free();
	M2.Free();
	M3.Free();
}
